careatorApp.controller('internalPostCtrl', function ($scope, $state, careatorHttpFactory, careatorSessionAuth) {
    console.log("internalPostCtrl++++++>>>>>>");
})