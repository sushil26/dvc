app.controller('analyticsCtl', function ($scope, $rootScope, $window, httpFactory) {
    console.log("dashboardEditController==>");





})