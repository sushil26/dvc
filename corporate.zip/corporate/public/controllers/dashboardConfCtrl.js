app.controller('dashboardConfCtrl',function ($scope, $rootScope, $window, httpFactory) {
    console.log("dashboardConfCtrl==>");





})