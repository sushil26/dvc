app.controller('dashboardEventController', function ($scope, $rootScope, $window, httpFactory) {
    console.log("dashboardController==>");


   
  





})